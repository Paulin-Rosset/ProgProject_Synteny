Bonjour et bienvenue dans le dossier regroupant les fichiers indispensables à la mise en route du projet.
Voici une description rapide des fichiers s'y trouvant :
•	rapport.pdf : fichier regroupant les motivations, la description du déroulé et les remarques sur le projet.
•	interface.ipnyb : fichier notebook permettant de lancer l’interface Tkinter facilement et de tester rapidement le code.
•	module.py : fichier regroupant le code nécessaire au projet.
•	script_tkinter.py : fichier regroupant le code nécessaire à l’interface Tkinter.
•	modulebackup.py : fichier regroupant le code nécessaire à la partie backup du fichier interface.ipnyb, en cas de problèmes sur l’interface Tkinter. 

N'oubliez pas de regarder l'interface Notebook avant de lancer notre programme, celle-ci explique comment bien lancer le programme pour qu'il marche.
